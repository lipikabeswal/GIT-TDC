Folder to temporarily contain audit information.

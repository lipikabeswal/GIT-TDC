Folder to contain encrypted content.

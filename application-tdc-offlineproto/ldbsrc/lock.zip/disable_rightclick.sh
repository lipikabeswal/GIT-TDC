xmodmap -e "pointer = 1 6 7 8 9"


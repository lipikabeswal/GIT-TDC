killall -9 gnome-panel-screenshot
killall -9 gnome-screenshot


xmodmap -pke > xmodmap_original


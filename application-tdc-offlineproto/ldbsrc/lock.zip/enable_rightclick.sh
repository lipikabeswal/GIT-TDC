xmodmap -e "pointer = 1 2 3 4 5"


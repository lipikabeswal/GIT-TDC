#include <stdio.h>

int main()
{
system("sh loadoriginal.sh");
//system("sh print_screen_enable.sh");
//system("find /usr/bin -type f -name \"gnome-panel-screenshot\" -exec chmod 755 {} \\;");
return 0;
}
